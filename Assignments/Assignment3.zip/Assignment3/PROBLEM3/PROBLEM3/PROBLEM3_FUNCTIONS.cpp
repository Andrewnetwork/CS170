//PROBLEM3_FUNCTIONS.cpp
//Andrew Ribeiro 
//December 6, 2008

#include <string>
#include <iostream> 
using namespace std;

